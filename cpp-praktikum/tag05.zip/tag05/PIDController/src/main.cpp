#include "PIDController.h"
#include <iostream>
#include <fstream>

int main()
{
	PIDController controller(1000, 10, 0.1 , 0.5);

	std::fstream file;

	file.open("../PIDControllerInput.txt");

	if (!file.is_open())
	{
		std::cout << "unable to open PIDControllerInput.txt.";
		return 1;
	}

	double sollwert;
	double istwert;

	while (file >> sollwert >> istwert)
	{
		controller.CalculateU(sollwert, istwert);

		std::cout << "Soll: " << sollwert << " | Ist: " << istwert << "| U: " << controller.GetU() << '\n';

	}
	file.close();



}
